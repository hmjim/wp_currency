<?php
   /*
   Plugin Name: Curency calculator
   Description: a plugin to convert valute
   Version: 1.0
   Author: Alekhin Maxim
   Author URI: http://hmjim.ru
   */


if (!class_exists('CurCalc')) {
 class CurCalc {
 
	## Хранение внутренних данных
	public $data = array();
	
	## Конструктор объекта
	## Инициализация основных переменных
	function CurCalc()
	{
		global $wpdb;
		
		## Объявляем константу инициализации нашего плагина
		DEFINE('CurCalc', true);
		
		## Название файла нашего плагина 
		$this->plugin_name = plugin_basename(__FILE__);
		
		## URL адресс для нашего плагина
		$this->plugin_url = trailingslashit(WP_PLUGIN_URL.'/'.dirname(plugin_basename(__FILE__)));
		
		## Таблица для хранения наших отзывов
		## обязательно должна быть глобально объявлена перменная $wpdb
		$this->tbl_CurCalc   = $wpdb->prefix . 'curcalc';
		
		## Функция которая исполняется при активации плагина
		register_activation_hook( $this->plugin_name, array(&$this, 'activate') );
		
		## Функция которая исполняется при деактивации плагина
		register_deactivation_hook( $this->plugin_name, array(&$this, 'deactivate') );
		
		##  Функция которая исполняется удалении плагина
		register_uninstall_hook( $this->plugin_name, array(&$this, 'uninstall') );
		
		// Если мы в адм. интерфейсе
		if ( is_admin() ) {
			
			// Добавляем стили и скрипты
			add_action('wp_print_scripts', array(&$this, 'admin_load_scripts'));
			add_action('wp_print_styles', array(&$this, 'admin_load_styles'));
			
			// Добавляем меню для плагина
			add_action( 'admin_menu', array(&$this, 'admin_generate_menu') );
			
		} else {
		    // Добавляем стили и скрипты
			add_action('wp_print_scripts', array(&$this, 'site_load_scripts'));
			add_action('wp_print_styles', array(&$this, 'site_load_styles'));
			

			add_shortcode( 'currency', array( &$this, 'site_show_CurCalc' ) );
		}
	}
	
	/**
	 * Загрузка необходимых скриптов для страницы управления 
	 * в панели администрирования
	 */
	function admin_load_scripts()
	{
		// Региестрируем скрипты
		wp_register_script('CurCalcAdminJs', $this->plugin_url . 'js/admin-scripts.js' );
		wp_register_script('jquery', $this->plugin_url . 'js/jquery.min.js' );
		
		// Добавляем скрипты на страницу
		wp_enqueue_script('CurCalcAdminJs');
		wp_enqueue_script('jquery');
	}
	
	/**
	 * Загрузка необходимых стилей для страницы управления 
	 * в панели администрирования
	 */
	function admin_load_styles()
	{	
		// Регистрируем стили 
		wp_register_style('CurCalcAdminCss', $this->plugin_url . 'css/admin-style.css' );
		// Добавляем стили
        wp_enqueue_style('CurCalcAdminCss');
	}
	
	/**
 	 * Генерируем меню
	 */
	function admin_generate_menu()
	{
		// Добавляем основной раздел меню
		add_menu_page('Currency converter', 'Currency', 'manage_options', 'edit-curcalc', array(&$this, 'admin_edit_Curcalc'));
		// Добавляем дополнительный раздел
		add_submenu_page( 'edit-curcalc', 'Manage', 'About', 'manage_options', 'plugin_info', array(&$this,'admin_plugin_info'));
	}
	
	/**
	 * Выводим список для редактирования
	 */
	public function admin_edit_Curcalc()
	{
		global $wpdb;
		
		$action = isset($_GET['action']) ? $_GET['action'] : null ;
		if (isset($_POST['action']) && $_POST['action'] == 'add-curcalc') {
			$this->add_front_CurCalc();
		}		
		switch ($action) {
		
			case 'edit':
				// Получаем данные из БД
				$this->data['curcalc'] 	= $wpdb->get_row("SELECT * FROM `" . $this->tbl_CurCalc . "` WHERE `ID`= ". (int)$_GET['id'], ARRAY_A);
				
				// Подключаем страницу для отображения результатов 
				include_once('edit_cur.php');
			break;
			
			case 'submit':
				$inputData = array(
					'curcalc_title' 	  	  => strip_tags($_POST['curcalc_title']),
					'curcalc_text' 		  => strip_tags($_POST['curcalc_text']),
				);
			
				$editId=intval($_POST['id']);
			
				if ($editId == 0) return false;
			
				// Обновляем существующую запись
				$wpdb->update( $this->tbl_CurCalc, $inputData, array( 'ID' => $editId ));
				
				// Показываем список 
				$this->admin_show_CurCalc();
			break;
			
			case 'delete':
			
				// Удаляем существующую запись
				$wpdb->query("DELETE FROM `".$this->tbl_CurCalc."` WHERE `ID` = '". (int)$_GET['id'] ."'");
				
				// Показываем список 
				$this->admin_show_CurCalc();
			break;
			
			default:
				$this->admin_show_CurCalc();
		}
		
	}
	
	/**
	 * Функция для отображения списка в адм. панели
	 */
	private function admin_show_CurCalc()
	{
		global $wpdb;
		
		// Получаем данные из БД
		$this->data['curcalc'] 	 = $wpdb->get_results("SELECT * FROM `" . $this->tbl_CurCalc . "`", ARRAY_A);
		
		// Подключаем страницу для отображения результатов 
		include_once('view_cur.php');
	}
	
	/**
	 * Показываем статическую страницу
	 */
	public function admin_plugin_info()
	{
		include_once('plugin_info.php');
	}
	
	function site_load_scripts()
	{
		wp_register_script('jquery', $this->plugin_url . 'js/jquery.min.js' );
		wp_register_script('CurCalcJs', $this->plugin_url . 'js/site-scripts.js' );
		wp_enqueue_script('jquery');
		wp_enqueue_script('CurCalcJs');
	}

	function site_load_styles()
	{
		wp_register_style('CurCalcCss', $this->plugin_url . 'css/site-style.css' );
		wp_enqueue_style('CurCalcCss');
	}
	
	/**
	 * Список на сайте
	 */


	public function site_show_CurCalc($atts, $content=null)
	{
		global $wpdb;
				
		// Выбираем все из Базы Данных
		$this->data['curcalc'] = $wpdb->get_results("SELECT * FROM `" . $this->tbl_CurCalc . "`", ARRAY_A);
		
		## Включаем буферизацию вывода
		ob_start ();
		include_once('site_cur.php');
		## Получаем данные
		$output = ob_get_contents ();
		## Отключаем буферизацию
		ob_end_clean ();
		
		return $output;
	}
	
	public function add_front_CurCalc() 
	{
		global $wpdb;
		
		$inputData = array(
			'curcalc_title' 	  	  => strip_tags($_POST['curcalc_title']),
			'curcalc_text' 		  => strip_tags($_POST['curcalc_text']),
		);
		
			
		$wpdb->insert( $this->tbl_CurCalc, $inputData );
	}
		
	
	/**
	 * Активация плагина
	 */
	function activate() 
	{
		global $wpdb;
		
		require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
		
		$table	= $this->tbl_CurCalc;
		
		## Определение версии mysql
		if ( version_compare(mysql_get_server_info(), '4.1.0', '>=') ) {
			if ( ! empty($wpdb->charset) )
				$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
			if ( ! empty($wpdb->collate) )
				$charset_collate .= " COLLATE $wpdb->collate";
		}
		
		## Структура нашей таблицы для отзывов
		$sql_table_CurCalc = "
		CREATE TABLE `".$wpdb->prefix."wp_curcalc` (
		  `id` int(10) NOT NULL,
		  `curcalc_title` text COLLATE ".$charset_collate." NOT NULL,
		  `curcalc_text` varchar(200) COLLATE ".$charset_collate." NOT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=".$charset_collate.";";		
		## Проверка на существование таблицы	
		if ( $wpdb->get_var("show tables like '".$table."'") != $table ) {
			dbDelta($sql_table_CurCalc);
		}
		
	}
	
	function deactivate() 
	{
		return true;
	}
	
	/**
	 * Удаление плагина
	 */
	function uninstall() 
	{
		global $wpdb;
		
		$wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}curcalc");
	}

 }
}

global $reviews;

$reviews = new CurCalc();

?>