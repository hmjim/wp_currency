<div class="wrap">
<h2>Information about the plugin "Currency calculator"</h2>

<div>
 <p><strong>Author: </strong> Alekhin Maxim </p>
 <p><strong>Date of creation: </strong> September 5, 2017</p>
 <p><strong>Email:</strong> <a href="mailto:hmjim@mail.ru">hmjim@mail.ru</a></p>
 <p><strong>Сайт:</strong> <a href="http://hmjim.ru">hmjim.ru</a></p>
</div>
</div>