<div class="wrap">
<h2>Managing currencies on the site</h2>

<div id="center-panel" style="width: 95%; margin: 3px auto 3px auto;">
	 <table class="widefat">
	  <thead>
	    <tr class="table-header">
		 <th>Currency</th>
		 <th>Rate</th>
		</tr>
	  </thead>
	  
	  <tbody>
	   <?php if (count($this->data['curcalc']) > 0): ?>
	   <?php foreach ($this->data['curcalc'] as $key => $record): ?>
		<tr>
		 <td class="curency">  
		  <div><?php echo $record['curcalc_title'] ?></div>
		 </td>
		 <td class="rate">
		  <div><?php echo $record['curcalc_text'] ?></div>
		 </td>
		 <td class="actions">
		  <div><a href="admin.php?page=edit-curcalc&action=edit&id=<?php echo $record['id']; ?>">Change</a></div>
		  <div><a onclick="return deleteService(); " href="admin.php?page=edit-curcalc&action=delete&id=<?php echo $record['id'];?>">Delete</a></div>
		 </td>
		</tr>
	   <?php endforeach; ?>
		 <form action="" method="POST">
		  <table class="input-table" style="width:100%; margin:0 auto;">
		   <tr>
		   <td colspan="2">
			<dl>
			 <dt><label for="curcalc_title">Currency:</label></dt>
			 <dd><input type="text" name="curcalc_title" id="curcalc_title"/></dd>
			</dl>
			
			<dl>
			 <dt><label for="curcalc_text">Ratio to the ruble:</label></dt>
			 <dd><input name="curcalc_text" id="curcalc_text"></dd>
			</dl>
		   </td>
		   </tr>
		  </table>
		  <div style="text-align:center">
			<input type="hidden" name="action" value="add-curcalc" />
			<input type="submit" name="send" value="Add" />
		  </div>
		 </form>	   
	   <?php else:?>
	    <tr>
		 <td colspan="4" style="text-align:center">No currencies</td>
		</tr>
	    <tr>
		 <form action="" method="POST">
		  <table class="input-table" style="width:100%; margin:0 auto;">
		   <tr>
		   <td colspan="2">
			<dl>
			 <dt><label for="curcalc_title">Currency:</label></dt>
			 <dd><input type="text" name="curcalc_title" id="curcalc_title"/></dd>
			</dl>
			
			<dl>
			 <dt><label for="curcalc_text">Ratio to the ruble:</label></dt>
			 <dd><input name="curcalc_text" id="curcalc_text"></dd>
			</dl>
		   </td>
		   </tr>
		  </table>
		  <div style="text-align:center">
			<input type="hidden" name="action" value="add-curcalc" />
			<input type="submit" name="send" value="Add" />
		  </div>
		 </form>
		</tr>
	   <?php endif;?>
	  </tbody>

	 </table> 
</div> 
</div>

