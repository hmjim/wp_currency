// JavaScript Document
// необходимые скрипты для админ панели

function deleteService() {
	var answer = confirm("Вы действительно хотите удалить?");
	return answer;
}