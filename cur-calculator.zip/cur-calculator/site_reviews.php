<div id="center-panel">

<?php
$json_cur = json_encode($this->data['curcalc']);
?>
 <?php if (count( $this->data['curcalc'] ) == 0): ?>
 <div id="list" class="noelements">
  <p style="text-align:center;">No currencies!</p>
 </div>
 <?php else: ?>

 <div id="list-one">
 <form>
   <p><select size="<?php echo count($this->data['curcalc']);?>" multiple name="cur">
   <option disabled>Choose currency</option>
  <?php foreach ($this->data['curcalc'] as $key => $record): ?>
		<option value="<?php echo $record['curcalc_text'] ?>"><?php echo $record['curcalc_title'] ?></option>
  <?php endforeach; ?>
   </select></p>
 </div>
  <div id="list-two">

   <p><select size="<?php echo count($this->data['curcalc']);?>" multiple name="cur">
   <option disabled>Choose currency</option>
  <?php foreach ($this->data['curcalc'] as $key => $record): ?>
		<option value="<?php echo $record['curcalc_text'] ?>"><?php echo $record['curcalc_title'] ?></option>
  <?php endforeach; ?>
   </select></p>
   <p><input id='count_m' type="input" placeholder='enter amount of money'  value=""></p>
   <p><input id='calculate' type="submit" value="Calculate"></p>
  </form>
  <div id='itogo'></div>
 <?php endif;?>
 </div> 
</div> 
<script>
(function($){
	var json_currency_calc = JSON.parse('<?php echo $json_cur?>');
	$(document).ready(function(){
		var mnojitel = 0;
		var count_m = 0;
		var delimoe = 0;
		var itogo = '';
		$('#calculate').on('click', function(){
			if($('#list-one option:selected').text() == '' || $('#list-two option:selected').text() == '' || $('#count_m').val() == ''){
				alert('Please fill in all fields!');
			}
			else{
				for (var i = 0; json_currency_calc.length > i; i++){
					if(json_currency_calc[i].curcalc_title == $('#list-one option:selected').text()){
						mnojitel = json_currency_calc[i].curcalc_text;
					}
					if(json_currency_calc[i].curcalc_title == $('#list-two option:selected').text()){
						delimoe = json_currency_calc[i].curcalc_text;
						valuta = json_currency_calc[i].curcalc_title;
					}					
					count_m = $('#count_m').val();
				}
			itogo = 'Total: ' + (count_m*mnojitel/delimoe).toFixed(2) + " " + valuta;
			$('#itogo').html(itogo);
			}
			return false;
		});
	});
})(jQuery);
</script>
