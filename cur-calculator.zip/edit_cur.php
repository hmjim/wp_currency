<div class="wrap" id="center-panel">
<h2>Currency editing</h2>

 <form action="admin.php?page=edit-curcalc&action=submit" method="POST">
  <table class="input-table" style="width:100%; margin:0 auto;">
   <tr>
   <td colspan="2">
    <dl>
	 <dt><label for="curcalc_title">Currency:</label></dt>
	 <dd><input type="text" name="curcalc_title" id="curcalc_title" value="<?php echo $this->data['curcalc']['curcalc_title'] ?>"/></dd>
	</dl>
	
	<dl>
	 <dt><label for="curcalc_text">Rate:</label></dt>
	 <dd><input name="curcalc_text" id="curcalc_text" value="<?php echo $this->data['curcalc']['curcalc_text'] ?>"></dd>
	</dl>
   </td>
   </tr>
  </table>
  <div style="text-align:center">
    <input type="hidden" name="id" value="<?php echo $this->data['curcalc']['id'] ?>" />
	<input type="submit" class="button" name="send" value="Change" />
  </div>
 </form>
</div> 
